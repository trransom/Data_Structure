package edu.svu.csc326;

import java.util.Iterator;

/**
 *
 * @author trran
 */
public class BinaryTree<T extends Comparable> implements Tree<T> {

    private Node root = null;
    private int count = 0;

    class Node {

        T data;
        Node parent;
        Node lchild;
        Node rchild;

        public Node(T data) {
            this(data, null);
        }

        public Node(T data, Node parent) {
            this.data = data;
            this.parent = parent;
            lchild = null;
            rchild = null;
        }
        
        public String toString(){
            return "(" + data + " "+ lchild + " " + rchild + ")";
        }

    }

    /**
     * Returns the size of the binary tree.
     * @return 
     */
    @Override
    public int size() {
        return count;
    }

    /**
     * Returns true if the tree is empty.
     * @return 
     */
    @Override
    public boolean isEmpty() {
        return root == null;
    }

    /**
     * Returns true if the tree contains the element
     * @param element
     * @return 
     */
    @Override
    public boolean contains(T element) {
        return contains(element, root);
    }

    private boolean contains(T element, Node n) {
        if (n == null) {
            return false;
        }
        if (n.data.compareTo(element) == 0) {
            return true;
        }
        if (n.data.compareTo(element) > 0) {
            return contains(element, n.lchild);
        } else {
            return contains(element, n.rchild);
        }
    }
    
    /**
     * Adds an element to the tree.
     * @param element
     * @return 
     */
    public Tree<T> add(T element) {
        if(root==null){
            root = new Node(element);
            return this;
        }
        return add(element, root);
    }

    private Tree<T> add(T element, Node n) {
        if (n.data.compareTo(element) == 0) {
            //duplicate node
            return this;
        } else if (n.data.compareTo(element) > 0) {
            if (n.lchild == null) {
                n.lchild = new Node(element, n);
                count++;
                if(!balanced(n.parent)){
                    rebalance(n.parent);
                }
                return this;
            } else {
                return add(element, n.lchild);
            }
        } else {
            if (n.rchild == null) {
                n.rchild = new Node(element, n);
                count++;
                if(!balanced(n.parent)){
                    rebalance(n.parent);
                }
                return this;
            } else {
                return add(element, n.rchild);
            }
        }
    }
    
    private Tree<T> rebalance(Node n){
        if((depth(n.lchild)>depth(n.rchild)) && n.lchild.lchild!=null){
            rotateRight(n);
            if(!balanced(n.parent)){
                rebalance(n.parent);
            }
        } else if(((depth(n.rchild)>depth(n.lchild)) && n.rchild.rchild!=null)){
            rotateLeft(n);
            if(!balanced(n.parent)){
                rebalance(n.parent);
            }
        } else if((depth(n.lchild)>depth(n.rchild)) && n.lchild.rchild!=null){
            rotateLeftRight(n);
            if(!balanced(n.parent)){
                rebalance(n.parent);
            }
        } else if(((depth(n.rchild)>depth(n.lchild)) && n.rchild.rchild!=null)){
            rotateRightLeft(n); 
            if(!balanced(n.parent)){
                rebalance(n.parent);
            }
        }
        return this;
    }
    
    private Node rotateLeft(Node t){
        Node temp = t.rchild;
        t.rchild = temp.lchild;
        temp.lchild = t;
        t = temp;
        return t; 
    }
    
    private Node rotateRight(Node t){
        Node temp = t.lchild;
        t.lchild = temp.rchild;
        temp.rchild = t;
        t = temp;
        return t;
    }
    
    private void rotateLeftRight(Node t){
        rotateLeft(t.lchild);
        rotateRight(t);
    }
    
    private void rotateRightLeft(Node t){
        
        rotateRight(t.rchild);
        rotateLeft(t);
    }
    

    @Override
    public Tree<T> remove(T element) {
        return this;
    }
    
    public int depth(){
        return depth(root);
    }
    
    private int depth(Node n){
        if(n==null){
            return 0;
        }
        return 1 + Math.max(depth(n.lchild), depth(n.rchild));
    }
    
    public boolean balanced(){
        return balanced(root);
    }
    
    private boolean balanced(Node n){
        if(n==null) return true;
        return Math.abs(depth(n.lchild)-depth(n.rchild)) <= 1;
    }

    @Override
    public Iterator<T> preIterator() {
        return new PreOrderIterator();
    }

    @Override
    public Iterator<T> postIterator() {
        return new PostOrder();
    }

    @Override
    public Iterator<T> inIterator() {
        return new InOrderIterator();
    }

    @Override
    public Iterator<T> iterator() {
        return inIterator();
    }
    
    public String toString(){
        return root.toString();
    }
    
    
    class InOrderIterator implements Iterator<T> {
        Queue<T> nodes = new QueueList<>();
        
        public InOrderIterator(){
            addNode(root);
        }
        
        void addNode(Node n){
            if(n!=null){
            addNode(n.lchild);
            nodes.add(n.data);
            addNode(n.rchild);
            }
        }

        @Override
        public boolean hasNext() {
           return !nodes.isEmpty(); 
        }

        @Override
        public T next() {
            return nodes.remove();
        }
        
    }
    
    class PreOrderIterator implements Iterator<T>{
        
        Queue<T> nodes = new QueueList<>();
        
        public PreOrderIterator(){
            addNode(root);
        }
        
        void addNode(Node n){
            if(n!=null){
            
            nodes.add(n.data);
            addNode(n.lchild);
            addNode(n.rchild);
            }
        }

        @Override
        public boolean hasNext() {
           return !nodes.isEmpty();
        }

        @Override
        public T next() {
            return nodes.remove();
        }
        
    }
    
    class PostOrder implements Iterator<T> {
         Queue<T> nodes = new QueueList<>();
        
        public PostOrder(){
            addNode(root);
        }
        
        void addNode(Node n){
            if(n!=null){
            addNode(n.lchild);
            addNode(n.rchild);
            nodes.add(n.data);
            }
        }

        @Override
        public boolean hasNext() {
           return !nodes.isEmpty();
        }

        @Override
        public T next() {
            return nodes.remove();
        }
    }

    

}
